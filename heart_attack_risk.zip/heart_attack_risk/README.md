#hear_attack_risk
